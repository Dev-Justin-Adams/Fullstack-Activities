import { Field, ID, ObjectType } from '@nestjs/graphql';

@ObjectType()
export class ActivityModel {
  @Field(() => ID)
  id: string;

  @Field()
  title: string;

  @Field()
  message: string;

  @Field()
  category: string;

  @Field({ nullable: true })
  expiresAt?: string;

  @Field()
  createdAt: string;
}
