import { Resolver, Query, Mutation, Args, Subscription } from '@nestjs/graphql';
import { ActivitiesService } from './activities.service';
import { CreateActivityInput } from './dto/create-activity.input';
import { ActivityModel } from './entities/activity.model';
import { PubSub } from 'graphql-subscriptions';

const pubSub = new PubSub();
const ACTIVITY_CREATED = 'ACTIVITY_CREATED';

@Resolver(() => ActivityModel)
export class ActivitiesResolver {
  constructor(private readonly activitiesService: ActivitiesService) {}

  @Query(() => [ActivityModel])
  async getActivities() {
    return this.activitiesService.findActive();
  }

  @Mutation(() => ActivityModel)
  async createActivity(@Args('input') input: CreateActivityInput) {
    const activity = await this.activitiesService.create(input);
    // publish the newly created activity to subscribers
    pubSub.publish(ACTIVITY_CREATED, { activityCreated: activity });
    return activity;
  }

  @Subscription(() => ActivityModel, {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-return, @typescript-eslint/no-unsafe-member-access
    resolve: (payload: any) => payload.activityCreated,
  })
  activityCreated() {
    return pubSub.asyncIterator(ACTIVITY_CREATED);
  }
}
