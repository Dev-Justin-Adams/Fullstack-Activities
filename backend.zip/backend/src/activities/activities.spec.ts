import { Test, TestingModule } from '@nestjs/testing';
import { ActivitiesResolver } from './activities.resolver';
import { ActivitiesService } from './activities.service';
import { CreateActivityInput } from './dto/create-activity.input';

describe('ActivitiesResolver', () => {
  let resolver: ActivitiesResolver;
  let service: Partial<ActivitiesService>;

  beforeEach(async () => {
    service = {
      create: jest.fn().mockImplementation((dto: CreateActivityInput) =>
        Promise.resolve({
          id: 'abc123',
          ...dto,
          createdAt: new Date().toISOString(),
        }),
      ),
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ActivitiesResolver,
        { provide: ActivitiesService, useValue: service },
      ],
    }).compile();

    resolver = module.get<ActivitiesResolver>(ActivitiesResolver);
  });

  it('creates an activity and returns it', async () => {
    const input: CreateActivityInput = {
      title: 'Hello',
      message: 'This is a test',
      category: 'test',
      expiresAt: undefined,
    };

    const result = await resolver.createActivity(input);

    expect(result).toBeTruthy();
    expect((service.create as jest.Mock).mock.calls.length).toBe(1);
    expect(result.title).toBe(input.title);
  });
});
