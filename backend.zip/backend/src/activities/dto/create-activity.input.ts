import { InputType, Field } from '@nestjs/graphql';
import { IsNotEmpty, IsOptional, IsDateString } from 'class-validator';

@InputType()
export class CreateActivityInput {
  @Field()
  @IsNotEmpty()
  title: string;

  @Field()
  @IsNotEmpty()
  message: string;

  @Field()
  @IsNotEmpty()
  category: string;

  @Field({ nullable: true })
  @IsOptional()
  @IsDateString()
  expiresAt?: string; // ISO date string
}
