/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-return */
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Activity } from './schemas/activity.schema';
import { CreateActivityInput } from './dto/create-activity.input';

@Injectable()
export class ActivitiesService {
  constructor(
    @InjectModel(Activity.name) private activityModel: Model<Activity>,
  ) {}

  // create -> save, convert to plain object, force ISO strings
  async create(createDto: CreateActivityInput) {
    const created = new this.activityModel({
      title: createDto.title,
      message: createDto.message,
      category: createDto.category,
      expiresAt: createDto.expiresAt
        ? new Date(createDto.expiresAt)
        : undefined,
    });

    const saved = await created.save();

    const obj: any = saved.toObject({ virtuals: true });
    const savedAny: any = saved;
    obj.createdAt = savedAny.createdAt
      ? savedAny.createdAt.toISOString()
      : null;
    obj.expiresAt = savedAny.expiresAt
      ? savedAny.expiresAt.toISOString()
      : null;

    return obj;
  }

  // findActive -> return plain objects with ISO strings
  async findActive() {
    const now = new Date();
    const docs = await this.activityModel
      .find({
        $or: [
          { expiresAt: { $gt: now } },
          { expiresAt: { $exists: false } },
          { expiresAt: null },
        ],
      })
      .sort({ createdAt: -1 })
      .exec();

    return docs.map((d: any) => {
      const obj: any = d.toObject({ virtuals: true });
      obj.createdAt = d?.createdAt ? (d.createdAt as Date).toISOString() : null;
      obj.expiresAt = d?.expiresAt ? (d.expiresAt as Date).toISOString() : null;
      return obj;
    });
  }
}
