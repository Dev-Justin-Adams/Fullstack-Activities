import React, { useEffect, useRef } from 'react'
import dayjs from 'dayjs'
import relativeTime from 'dayjs/plugin/relativeTime'
import { gql } from '@apollo/client'
import { useQuery } from '@apollo/client/react'

dayjs.extend(relativeTime)

const GET_ACTIVITIES = gql`
  query GetActivities {
    getActivities {
      id
      title
      message
      createdAt
      expiresAt
      category
    }
  }
`

const ACTIVITY_CREATED = gql`
  subscription ActivityCreated {
    activityCreated {
      id
      title
      message
      createdAt
      expiresAt
      category
    }
  }
`

function safeCreatedInfo(value) {
  if (value == null) return { iso: '', label: 'unknown time' };

  if (value instanceof Date) {
    if (!Number.isNaN(value.getTime())) return { iso: value.toISOString(), label: dayjs(value).fromNow() };
    return { iso: '', label: 'unknown time' };
  }

  if (typeof value === 'number') {
    const d = new Date(value);
    if (!Number.isNaN(d.getTime())) return { iso: d.toISOString(), label: dayjs(d).fromNow() };
    return { iso: '', label: 'unknown time' };
  }

  if (typeof value === 'string') {
    const d = new Date(value);
    if (!Number.isNaN(d.getTime())) return { iso: d.toISOString(), label: dayjs(d).fromNow() };
  }

  if (typeof value === 'object') {
    if (typeof value.toDate === 'function') {
      try {
        const d = value.toDate();
        if (!Number.isNaN(d.getTime())) return { iso: d.toISOString(), label: dayjs(d).fromNow() };
      } catch {}
    }
    if (value.$date) {
      const candidate = typeof value.$date === 'string'
        ? new Date(value.$date)
        : (value.$date.$numberLong ? new Date(Number(value.$date.$numberLong)) : null);
      if (candidate && !Number.isNaN(candidate.getTime())) return { iso: candidate.toISOString(), label: dayjs(candidate).fromNow() };
    }
    if (value.$numberLong) {
      const candidate = new Date(Number(value.$numberLong));
      if (!Number.isNaN(candidate.getTime())) return { iso: candidate.toISOString(), label: dayjs(candidate).fromNow() };
    }
  }

  // dev-only console.log without referencing `process`
  if (typeof window !== 'undefined' && window.__DEV__ !== false) {
    // eslint-disable-next-line no-console
    console.warn('ActivityList.safeCreatedInfo: unrecognized createdAt value:', value);
  }

  return { iso: '', label: 'unknown time' };
}


export default function ActivityList() {
  const { data, loading, error, subscribeToMore, refetch } = useQuery(GET_ACTIVITIES, {
    fetchPolicy: 'network-only',
  })

  // ensure we only subscribe once
  const subscribedRef = useRef(false)

  useEffect(() => {
    if (!subscribeToMore || subscribedRef.current) return
    subscribedRef.current = true

    const unsub = subscribeToMore({
      document: ACTIVITY_CREATED,
      updateQuery: (prev, { subscriptionData }) => {
        if (!subscriptionData?.data) return prev
        const newAct = subscriptionData.data.activityCreated
        const existing = prev?.getActivities || []

        // remove any exact-id duplicates
        let filtered = existing.filter(a => a.id !== newAct.id)

        // remove optimistic placeholders that match by heuristics:
        // items with temp- prefix and same title+message are considered placeholders
        filtered = filtered.filter(a => {
          if (!a.id) return true
          if (!String(a.id).startsWith('temp-')) return true
          // if title+message match, drop the optimistic placeholder
          return !(a.title === newAct.title && a.message === newAct.message)
        })

        return { getActivities: [newAct, ...filtered] }
      },
      onError(err) {
        // swallow or log subscription errors
        // console.warn('subscription error', err)
      },
    })

    return () => unsub && unsub()
  }, [subscribeToMore])

  if (loading) return <p>Loading…</p>
  if (error) return <p>Error: {error.message}</p>

  const activities = data?.getActivities || []
  

  return (
    <div className="list">
      <div className="controls">
        <button onClick={() => refetch()}>Refresh</button>
      </div>

      {activities.length === 0 && <p>No active activities</p>}

      {activities.map((act) => {
        const { iso, label } = safeCreatedInfo(act.createdAt)
        return (
          <article key={act.id} className="activity">
            <h2>{act.title}</h2>
            <p className="message">{act.message}</p>
            <div className="meta">
              <span>{act.category}</span>
              <time title={iso}>{label}</time>
            </div>
          </article>
        )
      })}
    </div>
  )
}
