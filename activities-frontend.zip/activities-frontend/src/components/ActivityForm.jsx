import React, { useState } from 'react'
import * as Apollo from '@apollo/client'
import { useMutation } from '@apollo/client/react'
const { gql } = Apollo

const CREATE_ACTIVITY = gql`
  mutation CreateActivity($input: CreateActivityInput!) {
    createActivity(input: $input) {
      id
      title
      message
      category
      createdAt
      expiresAt
    }
  }
`

export default function ActivityForm() {
  const [title, setTitle] = useState('')
  const [message, setMessage] = useState('')
  const [category, setCategory] = useState('')
  const [expiresAt, setExpiresAt] = useState('')

  const [createActivity, { loading }] = useMutation(CREATE_ACTIVITY, {
  onError(err) { console.warn('createActivity error', err) },
  refetchQueries: ['GetActivities'],     // <- refetch by operation name
  awaitRefetchQueries: true,
});


  const submit = async (e) => {
    e.preventDefault()
    if (!title.trim() || !message.trim() || !category.trim()) return

    await createActivity({
      variables: {
        input: {
          title: title.trim(),
          message: message.trim(),
          category: category.trim(),
          expiresAt: expiresAt ? new Date(expiresAt).toISOString() : undefined,
        },
      },
    })

    setTitle('')
    setMessage('')
    setCategory('')
    setExpiresAt('')
  }

  return (
    <form onSubmit={submit} style={{ marginBottom: 12 }}>
      <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
        <input
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
          style={{ flex: 1 }}
        />
        <input
          placeholder="Category"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          required
          style={{ width: 140 }}
        />
      </div>
      <div style={{ marginBottom: 8 }}>
        <textarea
          placeholder="Message"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          required
          rows={3}
          style={{ width: '100%' }}
        />
      </div>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
        <input
          type="datetime-local"
          value={expiresAt}
          onChange={(e) => setExpiresAt(e.target.value)}
          style={{ width: 220 }}
        />
        <button type="submit" disabled={loading}>
          {loading ? 'Sending…' : 'Create'}
        </button>
      </div>
    </form>
  )
}
