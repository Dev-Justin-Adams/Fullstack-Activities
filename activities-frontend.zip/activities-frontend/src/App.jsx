import React from 'react'
import ActivityList from './components/ActivityList.jsx'
import ActivityForm from './components/ActivityForm.jsx'


export default function App() {
return (
<div className="app">
<header>
<h1>ADMIN DASHBOARD</h1>
</header>
<main>
<ActivityList />
<h1>CREATE AN ACTIVITY</h1>
<ActivityForm />
</main>
</div>
)
}