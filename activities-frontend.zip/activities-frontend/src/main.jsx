import React from 'react'
import { createRoot } from 'react-dom/client'
import { ApolloClient, InMemoryCache, HttpLink, split } from '@apollo/client'
import { ApolloProvider } from '@apollo/client/react'
import { GraphQLWsLink } from '@apollo/client/link/subscriptions'
import { createClient } from 'graphql-ws'
import { getMainDefinition } from '@apollo/client/utilities'
import App from './App'
import './styles.css'


// Backend endpoints. Change if needed.
const HTTP_URL = import.meta.env.VITE_GRAPHQL_HTTP || 'http://localhost:3000/graphql'
const WS_URL = import.meta.env.VITE_GRAPHQL_WS || 'ws://localhost:3000/graphql'


const httpLink = new HttpLink({ uri: HTTP_URL })


const wsLink = typeof window !== 'undefined' ? new GraphQLWsLink(createClient({ url: WS_URL })) : null


const splitLink = wsLink
? split(
({ query }) => {
const def = getMainDefinition(query)
return def.kind === 'OperationDefinition' && def.operation === 'subscription'
},
wsLink,
httpLink,
)
: httpLink


const client = new ApolloClient({
link: splitLink,
cache: new InMemoryCache({
typePolicies: {
Query: {
fields: {
getActivities: {
merge(existing = [], incoming) {
return incoming
}
}
}
}
}
})
})


createRoot(document.getElementById('root')).render(
<React.StrictMode>
<ApolloProvider client={client}>
<App />
</ApolloProvider>
</React.StrictMode>
)