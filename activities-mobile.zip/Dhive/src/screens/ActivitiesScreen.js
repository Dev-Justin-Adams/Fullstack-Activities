import React, { useEffect, useRef } from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import * as Apollo from '@apollo/client';
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import { useQuery } from '@apollo/client/react';
dayjs.extend(relativeTime);

const { gql} = Apollo;

const GET_ACTIVITIES = gql`
  query GetActivities {
    getActivities {
      id
      title
      message
      createdAt
      expiresAt
      category
    }
  }
`;

const ACTIVITY_CREATED = gql`
  subscription ActivityCreated {
    activityCreated {
      id
      title
      message
      createdAt
      expiresAt
      category
    }
  }
`;

function safeCreatedInfo(value) {
  if (value == null) return { iso: '', label: 'unknown time' };
  if (value instanceof Date) return { iso: value.toISOString(), label: dayjs(value).fromNow() };
  if (typeof value === 'number') {
    const d = new Date(value);
    if (!Number.isNaN(d.getTime())) return { iso: d.toISOString(), label: dayjs(d).fromNow() };
    return { iso: '', label: 'unknown time' };
  }
  if (typeof value === 'string') {
    const d = new Date(value);
    if (!Number.isNaN(d.getTime())) return { iso: d.toISOString(), label: dayjs(d).fromNow() };
  }
  if (typeof value === 'object') {
    if (typeof value.toDate === 'function') {
      try {
        const d = value.toDate();
        if (!Number.isNaN(d.getTime())) return { iso: d.toISOString(), label: dayjs(d).fromNow() };
      } catch {}
    }
    if (value.$date) {
      const candidate = typeof value.$date === 'string'
        ? new Date(value.$date)
        : (value.$date.$numberLong ? new Date(Number(value.$date.$numberLong)) : null);
      if (candidate && !Number.isNaN(candidate.getTime())) return { iso: candidate.toISOString(), label: dayjs(candidate).fromNow() };
    }
  }
  return { iso: '', label: 'unknown time' };
}

export default function ActivitiesScreen() {
  const { data, loading, error, subscribeToMore, refetch } = useQuery(GET_ACTIVITIES, {
    fetchPolicy: 'network-only',
    // fallback polling if subscriptions are unavailable:
    // pollInterval: 5000,
  });

  const subscribedRef = useRef(false);

  useEffect(() => {
    if (!subscribeToMore || subscribedRef.current) return;
    subscribedRef.current = true;

    const unsub = subscribeToMore({
      document: ACTIVITY_CREATED,
      updateQuery: (prev, { subscriptionData }) => {
        if (!subscriptionData?.data) return prev;
        const newAct = subscriptionData.data.activityCreated;
        const existing = prev?.getActivities || [];

        // Map by id to dedupe; new item gets precedence
        const map = new Map();
        if (newAct?.id) map.set(newAct.id, newAct);
        existing.forEach(a => {
          if (a?.id && !map.has(a.id)) map.set(a.id, a);
        });

        // return array preserving newest-first order
        return { getActivities: Array.from(map.values()) };
      },
      onError(err) {
        console.warn('subscription error', err);
      },
    });

    return () => unsub && unsub();
  }, [subscribeToMore]);

  if (loading && !data) return <View style={styles.center}><Text>Loading…</Text></View>;
  if (error) return <View style={styles.center}><Text>Error: {error.message}</Text></View>;

  const activities = data?.getActivities || [];

  return (
    <View style={styles.container}>
      <h1>HELLO, HERE IS YOUR LIST OF ACTIVITIES</h1>
     <FlatList
        data={activities}
        keyExtractor={(item) => String(item.id)}
        // cross-platform refresh props (avoids rendering a RefreshControl element)
        refreshing={!!loading}
        onRefresh={() => refetch()}
        renderItem={({ item }) => {
          const { iso, label } = safeCreatedInfo(item.createdAt);
          return (
            <View style={styles.card}>
              <View style={styles.cardBar} />
              <View style={styles.cardBody}>
                <Text style={styles.title}>{item.title}</Text>
                <Text style={styles.message}>{item.message}</Text>
                <View style={styles.meta}>
                  <Text style={styles.badge}>{item.category}</Text>
                  <Text style={styles.time}>{label}</Text>
                </View>
              </View>
            </View>
          );
        }}
        ListEmptyComponent={<Text style={styles.empty}>No active activities</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingTop: 44, paddingHorizontal: 14, backgroundColor: '#f6f8fa' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  card: { flexDirection: 'row', backgroundColor: '#fff', borderRadius: 12, marginBottom: 12, overflow: 'hidden', elevation: 2, shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 8 },
  cardBar: { width: 6, backgroundColor: '#7c3aed' },
  cardBody: { flex: 1, padding: 12 },
  title: { fontSize: 16, fontWeight: '700', marginBottom: 6, color: '#081124' },
  message: { color: '#0b1220', marginBottom: 8, lineHeight: 18 },
  meta: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  badge: { backgroundColor: 'rgba(124,58,237,0.08)', color: '#5b21b6', paddingVertical: 4, paddingHorizontal: 8, borderRadius: 999, fontWeight: '700' },
  time: { color: '#6b7280', fontSize: 13 },
  empty: { textAlign: 'center', padding: 20, color: '#6b7280' },
});
