import 'react-native-url-polyfill/auto';
import React from 'react';
import { client } from './src/graphql/client.js';
import ActivitiesScreen from './src/screens/ActivitiesScreen.js';
import { ApolloProvider } from '@apollo/client/react';
export default function App() {
  return (
    <ApolloProvider client={client}>
      <ActivitiesScreen />
    </ApolloProvider>
  );
}
