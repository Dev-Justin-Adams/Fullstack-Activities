import * as Apollo from '@apollo/client';
import { GraphQLWsLink } from '@apollo/client/link/subscriptions';
import { createClient } from 'graphql-ws';
import { getMainDefinition } from '@apollo/client/utilities';
import { Platform } from 'react-native';

// Map host for environment
// Android emulator -> 10.0.2.2
// iOS simulator -> localhost
// Real device -> replace with your machine LAN IP e.g. 192.168.x.y
const HOST = Platform.OS === 'android' ? '10.198.162.24' : 'localhost';
const HTTP_URL = `http://${HOST}:3000/graphql`;
const WS_URL = `ws://${HOST}:3000/graphql`;

const { ApolloClient, InMemoryCache, HttpLink, split } = Apollo;

const httpLink = new HttpLink({ uri: HTTP_URL });

// graphql-ws link for React Native (global.WebSocket present)
const wsLink = typeof global !== 'undefined' && typeof global.WebSocket !== 'undefined'
  ? new GraphQLWsLink(createClient({
      url: WS_URL,
      webSocketImpl: global.WebSocket,
      // optional: lazy: true, keepAlive: 12_000
    }))
  : null;

const splitLink = wsLink
  ? split(
      ({ query }) => {
        const def = getMainDefinition(query);
        return def.kind === 'OperationDefinition' && def.operation === 'subscription';
      },
      wsLink,
      httpLink,
    )
  : httpLink;

export const client = new ApolloClient({
  link: splitLink,
  cache: new InMemoryCache({
    typePolicies: {
      Query: {
        fields: {
          getActivities: {
            merge(existing = [], incoming) { return incoming; }
          }
        }
      }
    }
  }),
});
